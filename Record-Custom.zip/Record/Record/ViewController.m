//
//  ViewController.m
//  Record
//
//  Created by liweidong on 17/8/1.
//  Copyright © 2017年 Sillen. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}




@end
