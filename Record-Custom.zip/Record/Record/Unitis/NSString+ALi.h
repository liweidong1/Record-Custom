//
//  NSString+ALi.h
//  ALiVideoRecorder
//
//  Created by liweidong on 17/8/1.
//  Copyright © 2017年 Sillen. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (ALi)
- (NSString *)MD5String;

@end
