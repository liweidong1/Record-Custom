//
//  ArtVideoModel.m
//  ALiVideoRecorder
//
//  Created by liweidong on 17/8/1.
//  Copyright © 2017年 Sillen. All rights reserved.
//

#import "ArtVideoModel.h"

@implementation ArtVideoModel
+ (instancetype)modelWithPath:(NSString *)videoPath thumPath:(NSString *)thumPath recordTime:(NSDate *)recordTime {
    ArtVideoModel *model = [[ArtVideoModel alloc] init];
    model.videoAbsolutePath = videoPath;
    model.thumAbsolutePath = thumPath;
    model.recordTime = recordTime;
    return model;
}
@end
